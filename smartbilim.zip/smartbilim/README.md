# SmartBilim — AI-powered Learning Platform for Kazakhstan Schools

**SmartBilim** is a modern educational web application designed for students (grades 7–11), teachers, and parents in Kazakhstan. It provides AI-assisted assignment analysis, personalized study plans, progress tracking, and role-based dashboards.

> **Primary language:** Kazakh (Қазақша)  
> **Target users:** Students aged 13–17, teachers, parents  
> **Status:** Frontend prototype with realistic demo data

---

## Features

### Student
- View overall and subject progress with charts
- Submit assignments for **demo AI analysis** (clearly labeled)
- Receive feedback, suggested scores, mistake explanations, and recommendations
- Personalized study plan with markable goals
- Strengths / improvement areas
- Local progress storage (localStorage)

### Teacher
- Class overview and statistics
- Student list with search/filter
- Common learning difficulties summary
- Review AI analyses and confirm grades (demo)
- Class comparison charts

### Parent
- Clear overview of their child’s progress only
- Subject-by-subject summaries
- Recommendations where support may be needed
- Progress charts over time

### Design
- Modern blue-and-white educational UI
- Responsive (desktop, tablet, mobile)
- Sidebar navigation
- Clean cards, progress bars, badges, charts (Chart.js)

---

## Demo Login

Open `login.html` and choose a role:

| Role     | Demo user              |
|----------|------------------------|
| Оқушы    | Айгерим Нұрланова (9-сынып) |
| Мұғалім  | Ерлан Сәтбаев (Математика) |
| Ата-ана  | Нұрлан Нұрланов         |

No real authentication — pure frontend demo.

---

## Project Structure

```
smartbilim/
├── index.html              # Landing page
├── login.html              # Login + role selection
├── css/
│   └── styles.css          # Shared styles
├── js/
│   ├── data.js             # Sample data + demo AI logic
│   └── app.js              # Navigation, forms, charts helpers
├── student/
│   ├── dashboard.html
│   ├── assignments.html    # Upload + AI analysis workflow
│   ├── study-plan.html
│   ├── analytics.html
│   └── settings.html
├── teacher/
│   ├── dashboard.html
│   ├── students.html
│   ├── analytics.html
│   └── settings.html
├── parent/
│   ├── dashboard.html
│   ├── progress.html
│   └── settings.html
└── README.md
```

---

## How to Run

1. Clone or download this repository.
2. Open `index.html` in a modern browser (or serve with any static server).

```bash
# Optional: simple local server
npx serve .
# or
python -m http.server 8000
```

Then visit `http://localhost:8000`.

---

## Demo AI Analysis

The assignment analysis is **intentionally a demo**:

- Results are generated from templates based on input length (for variety).
- Every result is labeled **«ДЕМО · Нақты AI емес»**.
- Suggested scores are clearly separated from teacher-confirmed grades.

### Future: Real AI Integration

Replace `runDemoAnalysis()` in `js/data.js` with a call to your backend:

```js
async function runDemoAnalysis(subjectId, text) {
  const res = await fetch('/api/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ subject: subjectId, content: text })
  });
  return res.json();
}
```

**Never put API keys in frontend code.** Use a secure backend proxy.

---

## Sample Subjects (Kazakhstan curriculum)

- Математика  
- Қазақ тілі  
- Орыс тілі  
- Ағылшын тілі  
- Физика  
- Биология  
- Тарих  

---

## Future Roadmap

- Real AI analysis API
- Secure authentication & role-based access
- Database for assignments and results
- File uploads
- Notifications & progress reports
- ҰБТ / exam preparation modules
- Mobile apps (Android / iOS)
- Early identification of students needing support
- Premium parent analytics
- Freemium + school licensing

---

## Privacy

- All data in this prototype is **fictional**.
- Parents can only see their linked child’s information.
- Role separation is enforced in the UI (backend must enforce it in production).

---

## Tech Stack

- HTML5, CSS3, vanilla JavaScript
- Chart.js (CDN)
- Font Awesome (CDN)
- localStorage for demo persistence

No build step required. Ready for future React / backend integration.

---

## License

MIT (or as preferred by the project owner).

---

**SmartBilim** — Қазақстан мектептеріне арналған зияткерлік оқу платформасы.

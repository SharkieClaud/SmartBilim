// SmartBilim - Sample Data & Demo Logic
// Қазақстан мектептері үшін үлгі деректер

const SUBJECTS = [
  { id: 'math', name: 'Математика', color: '#3b82f6' },
  { id: 'kazakh', name: 'Қазақ тілі', color: '#10b981' },
  { id: 'russian', name: 'Орыс тілі', color: '#8b5cf6' },
  { id: 'english', name: 'Ағылшын тілі', color: '#f59e0b' },
  { id: 'physics', name: 'Физика', color: '#ef4444' },
  { id: 'biology', name: 'Биология', color: '#06b6d4' },
  { id: 'history', name: 'Тарих', color: '#ec4899' }
];

const STUDENT_DATA = {
  id: 's1',
  name: 'Айгерим Нұрланова',
  grade: '9-сынып',
  school: '№12 жалпы білім беретін мектеп',
  avatar: 'АН',
  overallProgress: 78,
  subjects: [
    { id: 'math', score: 85, trend: 'up', assignments: 12 },
    { id: 'kazakh', score: 92, trend: 'up', assignments: 10 },
    { id: 'russian', score: 74, trend: 'down', assignments: 11 },
    { id: 'english', score: 81, trend: 'up', assignments: 9 },
    { id: 'physics', score: 68, trend: 'down', assignments: 8 },
    { id: 'biology', score: 88, trend: 'up', assignments: 10 },
    { id: 'history', score: 79, trend: 'stable', assignments: 7 }
  ],
  strengths: ['Қазақ тілі', 'Биология', 'Математика'],
  improvements: ['Физика', 'Орыс тілі'],
  recentAssignments: [
    { id: 1, subject: 'Математика', title: 'Квадрат теңдеулер', date: '2026-10-15', score: 90, status: 'graded', aiScore: 88 },
    { id: 2, subject: 'Физика', title: 'Ньютон заңдары', date: '2026-10-14', score: 65, status: 'graded', aiScore: 62 },
    { id: 3, subject: 'Қазақ тілі', title: 'Эссе: Менің болашағым', date: '2026-10-12', score: 95, status: 'graded', aiScore: 93 },
    { id: 4, subject: 'Ағылшын тілі', title: 'Present Perfect', date: '2026-10-10', score: null, status: 'pending', aiScore: 78 }
  ],
  studyGoals: [
    { id: 1, title: 'Физика: Ньютон заңдарын қайталау', subject: 'physics', completed: false, due: '2026-10-21' },
    { id: 2, title: 'Орыс тілі: Емле ережелері', subject: 'russian', completed: false, due: '2026-10-22' },
    { id: 3, title: 'Математика: 10 есеп шешу', subject: 'math', completed: true, due: '2026-10-18' },
    { id: 4, title: 'Биология: Жасуша құрылымы', subject: 'biology', completed: true, due: '2026-10-16' },
    { id: 5, title: 'Ағылшын: 20 жаңа сөз үйрену', subject: 'english', completed: false, due: '2026-10-23' }
  ],
  weeklyGoals: {
    completed: 4,
    total: 7,
    subjects: ['math', 'physics', 'russian']
  }
};

const TEACHER_DATA = {
  id: 't1',
  name: 'Ерлан Сәтбаев',
  subject: 'Математика',
  school: '№12 жалпы білім беретін мектеп',
  avatar: 'ЕС',
  classStats: {
    average: 76,
    studentsCount: 28,
    assignmentsThisWeek: 3,
    needsAttention: 5
  },
  students: [
    { id: 's1', name: 'Айгерим Нұрланова', grade: 9, avg: 78, math: 85, trend: 'up', lastActive: '2026-10-18' },
    { id: 's2', name: 'Данияр Қасымов', grade: 9, avg: 65, math: 58, trend: 'down', lastActive: '2026-10-17' },
    { id: 's3', name: 'Мәдина Әлиева', grade: 9, avg: 91, math: 95, trend: 'up', lastActive: '2026-10-18' },
    { id: 's4', name: 'Нұрлан Бекболат', grade: 9, avg: 72, math: 70, trend: 'stable', lastActive: '2026-10-16' },
    { id: 's5', name: 'Аружан Төлеу', grade: 9, avg: 88, math: 92, trend: 'up', lastActive: '2026-10-18' },
    { id: 's6', name: 'Темірлан Жұмабай', grade: 9, avg: 54, math: 48, trend: 'down', lastActive: '2026-10-14' },
    { id: 's7', name: 'Сабина Қуаныш', grade: 9, avg: 82, math: 80, trend: 'up', lastActive: '2026-10-17' },
    { id: 's8', name: 'Алихан Рахмет', grade: 9, avg: 69, math: 65, trend: 'stable', lastActive: '2026-10-15' }
  ],
  commonDifficulties: [
    { topic: 'Квадрат теңдеулер', students: 12, percentage: 43 },
    { topic: 'Геометриялық фигуралар', students: 9, percentage: 32 },
    { topic: 'Пайыздар', students: 7, percentage: 25 }
  ],
  recentAnalyses: [
    { student: 'Данияр Қасымов', assignment: 'Квадрат теңдеулер', aiScore: 52, teacherScore: null, date: '2026-10-17' },
    { student: 'Темірлан Жұмабай', assignment: 'Линейлік теңдеулер', aiScore: 45, teacherScore: 48, date: '2026-10-16' },
    { student: 'Айгерим Нұрланова', assignment: 'Квадрат теңдеулер', aiScore: 88, teacherScore: 90, date: '2026-10-15' }
  ]
};

const PARENT_DATA = {
  id: 'p1',
  name: 'Нұрлан Нұрланов',
  childName: 'Айгерим Нұрланова',
  childGrade: '9-сынып',
  avatar: 'НН',
  childProgress: STUDENT_DATA
};

// Demo AI analysis templates
const AI_ANALYSIS_TEMPLATES = {
  math: {
    good: {
      score: 88,
      feedback: 'Жалпы жұмыс жақсы орындалған. Квадрат теңдеулерді шешу алгоритмі дұрыс қолданылған.',
      mistakes: [
        { type: 'minor', text: '2-ші есепте дискриминантты есептеу кезінде белгі қатесі бар. (-b)² = b² екенін еске түсіріңіз.' },
        { type: 'minor', text: 'Жауапты тексеру қадамын толық жазбағансыз. Әрқашан табылған түбірлерді бастапқы теңдеуге қойып тексеріңіз.' }
      ],
      recommendations: [
        'Дискриминант формуласын қайталаңыз',
        'Теңдеу түбірлерін тексеру жаттығуларын орындаңыз',
        'Квадрат теңдеулер бойынша 5 қосымша есеп шешіңіз'
      ],
      topics: ['Квадрат теңдеулер', 'Дискриминант', 'Түбірлерді тексеру']
    },
    average: {
      score: 65,
      feedback: 'Негізгі ұғымдар түсінікті, бірақ есептеу қателері көп. Алгоритмді толық сақтау керек.',
      mistakes: [
        { type: 'major', text: '1-ші есепте a, b, c коэффициенттерін дұрыс анықтамағансыз.' },
        { type: 'major', text: 'Дискриминант D < 0 болғанда нақты түбір жоқ екенін ескермегенсіз.' },
        { type: 'minor', text: 'Жауап форматы толық емес.' }
      ],
      recommendations: [
        'Квадрат теңдеу анықтамасын қайталаңыз',
        'a, b, c коэффициенттерін табу жаттығулары',
        'D ≥ 0 және D < 0 жағдайларын бөлек жаттығыңыз'
      ],
      topics: ['Квадрат теңдеулер негіздері', 'Коэффициенттер', 'Дискриминант белгісі']
    },
    poor: {
      score: 42,
      feedback: 'Тақырыпты қайтадан зерттеу ұсынылады. Негізгі формулалар мен қадамдар дұрыс қолданылмаған.',
      mistakes: [
        { type: 'major', text: 'Квадрат теңдеудің жалпы түрін дұрыс жазбағансыз.' },
        { type: 'major', text: 'Дискриминант формуласы қате қолданылған.' },
        { type: 'major', text: 'Түбірлерді табу формуласы дұрыс емес.' }
      ],
      recommendations: [
        'Мұғаліммен қосымша сабақ өткізіңіз',
        'Оқулықтан «Квадрат теңдеулер» бөлімін қайта оқыңыз',
        'Қарапайым мысалдардан бастап жаттығыңыз'
      ],
      topics: ['Квадрат теңдеу анықтамасы', 'Негізгі формулалар']
    }
  },
  default: {
    score: 75,
    feedback: 'Жұмыс орташа деңгейде орындалған. Кейбір бөлімдерді қайта қарау қажет.',
    mistakes: [
      { type: 'minor', text: 'Кейбір жауаптарда түсініктеме жеткіліксіз.' },
      { type: 'minor', text: 'Форматтау ережелерін сақтаңыз.' }
    ],
    recommendations: [
      'Тақырыпты қайталаңыз',
      'Қосымша жаттығулар орындаңыз',
      'Мұғалімнен кеңес алыңыз'
    ],
    topics: ['Негізгі тақырыптар']
  }
};

// Progress over time (for charts)
const PROGRESS_HISTORY = {
  labels: ['Қыр', 'Қаз', 'Қар', 'Жел', 'Қаң', 'Ақп', 'Нау', 'Сәу', 'Мам', 'Мау'],
  overall: [62, 65, 68, 70, 72, 71, 74, 76, 77, 78],
  math: [70, 72, 75, 78, 80, 79, 82, 83, 84, 85],
  physics: [55, 58, 60, 62, 65, 63, 66, 67, 68, 68]
};

// Local storage helpers
const Storage = {
  get(key, defaultValue = null) {
    try {
      const val = localStorage.getItem('smartbilim_' + key);
      return val ? JSON.parse(val) : defaultValue;
    } catch {
      return defaultValue;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem('smartbilim_' + key, JSON.stringify(value));
    } catch (e) {
      console.warn('localStorage error', e);
    }
  },
  getGoals() {
    return this.get('goals', STUDENT_DATA.studyGoals);
  },
  setGoals(goals) {
    this.set('goals', goals);
  },
  getAssignments() {
    return this.get('assignments', STUDENT_DATA.recentAssignments);
  },
  addAssignment(assignment) {
    const list = this.getAssignments();
    list.unshift(assignment);
    this.set('assignments', list);
    return list;
  }
};

// Demo AI analysis function (clearly labeled as demo)
function runDemoAnalysis(subjectId, text) {
  return new Promise((resolve) => {
    // Simulate processing delay
    setTimeout(() => {
      const templates = AI_ANALYSIS_TEMPLATES[subjectId] || { average: AI_ANALYSIS_TEMPLATES.default };
      const keys = Object.keys(templates);
      // Simple heuristic based on text length for demo variety
      let result;
      if (text && text.length > 200) {
        result = templates.good || AI_ANALYSIS_TEMPLATES.default;
      } else if (text && text.length > 80) {
        result = templates.average || AI_ANALYSIS_TEMPLATES.default;
      } else {
        result = templates.poor || templates.average || AI_ANALYSIS_TEMPLATES.default;
      }
      resolve({
        ...result,
        isDemo: true,
        analyzedAt: new Date().toISOString(),
        subjectId
      });
    }, 1500 + Math.random() * 1000);
  });
}

function getSubjectName(id) {
  const s = SUBJECTS.find(x => x.id === id);
  return s ? s.name : id;
}

function getSubjectColor(id) {
  const s = SUBJECTS.find(x => x.id === id);
  return s ? s.color : '#3b82f6';
}

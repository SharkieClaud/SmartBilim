// SmartBilim - Application Logic

function initSidebar() {
  const toggle = document.getElementById('menuToggle');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebarOverlay');

  if (toggle && sidebar) {
    toggle.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      if (overlay) overlay.classList.toggle('show');
    });
  }
  if (overlay) {
    overlay.addEventListener('click', () => {
      sidebar.classList.remove('open');
      overlay.classList.remove('show');
    });
  }
}

function showToast(message, type = 'success') {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.className = 'toast ' + type + ' show';
  setTimeout(() => toast.classList.remove('show'), 3000);
}

function setActiveNav(page) {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.page === page);
  });
}

// Login / Role selection
function loginAs(role) {
  localStorage.setItem('smartbilim_role', role);
  localStorage.setItem('smartbilim_logged_in', 'true');
  if (role === 'student') {
    window.location.href = 'student/dashboard.html';
  } else if (role === 'teacher') {
    window.location.href = 'teacher/dashboard.html';
  } else if (role === 'parent') {
    window.location.href = 'parent/dashboard.html';
  }
}

function logout() {
  localStorage.removeItem('smartbilim_role');
  localStorage.removeItem('smartbilim_logged_in');
  window.location.href = '../index.html';
}

function checkAuth(expectedRole) {
  const loggedIn = localStorage.getItem('smartbilim_logged_in');
  const role = localStorage.getItem('smartbilim_role');
  if (!loggedIn || (expectedRole && role !== expectedRole)) {
    // Allow demo access without strict redirect for prototype
    // window.location.href = '../login.html';
  }
  return role;
}

// Student: toggle study goal
function toggleGoal(id) {
  const goals = Storage.getGoals();
  const goal = goals.find(g => g.id === id);
  if (goal) {
    goal.completed = !goal.completed;
    Storage.setGoals(goals);
    renderGoals();
    showToast(goal.completed ? 'Тапсырма орындалды!' : 'Тапсырма қайта ашылды');
  }
}

function renderGoals() {
  const container = document.getElementById('goalsList');
  if (!container) return;
  const goals = Storage.getGoals();
  container.innerHTML = goals.map(g => `
    <div class="goal-item ${g.completed ? 'completed' : ''}">
      <div class="goal-check ${g.completed ? 'checked' : ''}" onclick="toggleGoal(${g.id})">
        ${g.completed ? '✓' : ''}
      </div>
      <div class="goal-info">
        <h4>${g.title}</h4>
        <p>${getSubjectName(g.subject)} · Мерзімі: ${formatDate(g.due)}</p>
      </div>
    </div>
  `).join('');
}

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  return d.toLocaleDateString('kk-KZ', { day: 'numeric', month: 'short' });
}

// Assignment submission
async function submitAssignment(event) {
  event.preventDefault();
  const subject = document.getElementById('assignSubject').value;
  const title = document.getElementById('assignTitle').value.trim();
  const content = document.getElementById('assignContent').value.trim();
  const resultBox = document.getElementById('analysisResult');
  const submitBtn = document.getElementById('submitBtn');

  if (!title || !content) {
    showToast('Тақырып пен мазмұнды толтырыңыз', 'warning');
    return;
  }

  submitBtn.disabled = true;
  submitBtn.innerHTML = '<span class="spinner"></span> Талдау жүріп жатыр...';
  resultBox.style.display = 'none';

  try {
    const analysis = await runDemoAnalysis(subject, content);
    
    // Save to local storage
    const newAssign = {
      id: Date.now(),
      subject: getSubjectName(subject),
      title,
      date: new Date().toISOString().slice(0, 10),
      score: null,
      status: 'ai_reviewed',
      aiScore: analysis.score
    };
    Storage.addAssignment(newAssign);

    // Render result
    resultBox.innerHTML = `
      <h3>
        AI талдау нәтижесі
        <span class="analysis-demo-label">ДЕМО · Нақты AI емес</span>
      </h3>
      <p style="margin-bottom:1rem;color:var(--text-muted);font-size:0.9rem;">
        Бұл нәтиже үлгі деректер негізінде жасалған. Нақты AI сервисі қосылғанда мұнда нақты талдау көрсетіледі.
      </p>
      <div class="stats-grid" style="margin-bottom:1.25rem;">
        <div class="stat-card">
          <div class="stat-icon purple">📊</div>
          <div class="stat-info">
            <h3>${analysis.score}%</h3>
            <p>Ұсынылған баға (AI)</p>
          </div>
        </div>
      </div>
      <p style="margin-bottom:1rem;"><strong>Жалпы пікір:</strong> ${analysis.feedback}</p>
      <h4 style="margin-bottom:0.75rem;color:var(--primary-dark);">Қателер мен ескертулер:</h4>
      ${analysis.mistakes.map(m => `
        <div class="mistake-item ${m.type === 'minor' ? '' : ''}">
          <strong>${m.type === 'major' ? '⚠️ Маңызды' : 'ℹ️ Ескерту'}:</strong> ${m.text}
        </div>
      `).join('')}
      <h4 style="margin:1.25rem 0 0.75rem;color:var(--primary-dark);">Ұсыныстар:</h4>
      <ul style="padding-left:1.25rem;margin-bottom:1rem;">
        ${analysis.recommendations.map(r => `<li style="margin-bottom:0.35rem;">${r}</li>`).join('')}
      </ul>
      <h4 style="margin-bottom:0.75rem;color:var(--primary-dark);">Қайталауға ұсынылатын тақырыптар:</h4>
      <div class="tag-list">
        ${analysis.topics.map(t => `<span class="tag tag-improve">${t}</span>`).join('')}
      </div>
      <p style="margin-top:1.25rem;font-size:0.85rem;color:var(--text-muted);">
        <strong>Ескерту:</strong> AI ұсынған баға мұғалім растағанға дейін ресми емес. Мұғалім бағасын күтіңіз.
      </p>
    `;
    resultBox.style.display = 'block';
    showToast('Талдау аяқталды!');
  } catch (e) {
    showToast('Қате орын алды', 'danger');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = 'Талдауға жіберу';
  }
}

// Charts
function initProgressChart() {
  const ctx = document.getElementById('progressChart');
  if (!ctx || typeof Chart === 'undefined') return;

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: PROGRESS_HISTORY.labels,
      datasets: [
        {
          label: 'Жалпы үлгерім',
          data: PROGRESS_HISTORY.overall,
          borderColor: '#3b82f6',
          backgroundColor: 'rgba(59, 130, 246, 0.1)',
          fill: true,
          tension: 0.3
        },
        {
          label: 'Математика',
          data: PROGRESS_HISTORY.math,
          borderColor: '#10b981',
          backgroundColor: 'transparent',
          tension: 0.3
        },
        {
          label: 'Физика',
          data: PROGRESS_HISTORY.physics,
          borderColor: '#ef4444',
          backgroundColor: 'transparent',
          tension: 0.3
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom' }
      },
      scales: {
        y: { min: 40, max: 100, ticks: { callback: v => v + '%' } }
      }
    }
  });
}

function initSubjectChart() {
  const ctx = document.getElementById('subjectChart');
  if (!ctx || typeof Chart === 'undefined') return;

  const data = STUDENT_DATA.subjects;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: data.map(s => getSubjectName(s.id)),
      datasets: [{
        label: 'Баға (%)',
        data: data.map(s => s.score),
        backgroundColor: data.map(s => getSubjectColor(s.id) + 'cc'),
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { min: 0, max: 100, ticks: { callback: v => v + '%' } }
      }
    }
  });
}

function initClassChart() {
  const ctx = document.getElementById('classChart');
  if (!ctx || typeof Chart === 'undefined') return;

  const students = TEACHER_DATA.students;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: students.map(s => s.name.split(' ')[0]),
      datasets: [{
        label: 'Орташа баға',
        data: students.map(s => s.avg),
        backgroundColor: students.map(s => s.avg >= 80 ? '#10b981' : s.avg >= 65 ? '#3b82f6' : '#f59e0b'),
        borderRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { min: 0, max: 100 }
      }
    }
  });
}

// Render subject progress bars
function renderSubjectProgress() {
  const container = document.getElementById('subjectProgress');
  if (!container) return;
  container.innerHTML = STUDENT_DATA.subjects.map(s => `
    <div class="subject-item">
      <span class="subject-name">${getSubjectName(s.id)}</span>
      <div class="subject-bar">
        <div class="subject-bar-fill" style="width:${s.score}%;background:${getSubjectColor(s.id)}"></div>
      </div>
      <span class="subject-score">${s.score}%</span>
    </div>
  `).join('');
}

// Teacher filter
function filterStudents(query) {
  const rows = document.querySelectorAll('.student-row');
  const q = query.toLowerCase();
  rows.forEach(row => {
    const name = row.dataset.name || '';
    row.style.display = name.toLowerCase().includes(q) ? '' : 'none';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initSidebar();
});
